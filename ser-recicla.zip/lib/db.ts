import { prisma } from "../prisma"

export { prisma }
